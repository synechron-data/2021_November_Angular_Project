// class Queue {
//     private _data: number[] = [];

//     push(d: number) {
//         this._data.push(d);
//     }

//     pop(): number | undefined {
//         return this._data.shift();
//     }
// }

// var numbersQ = new Queue();
// numbersQ.push(10);
// numbersQ.push(20);
// numbersQ.push(30);

// console.log(numbersQ.pop());
// console.log(numbersQ.pop());
// console.log(numbersQ.pop());

// ---------------------------------------------- Flexibility, we can use 'any' as type
// class Queue {
//     private _data: any[] = [];

//     push(d: any) {
//         this._data.push(d);
//     }

//     pop(): any | undefined {
//         return this._data.shift();
//     }
// }

// var numbersQ = new Queue();
// numbersQ.push(10);
// numbersQ.push(20);
// numbersQ.push(30);

// console.log(numbersQ.pop());
// console.log(numbersQ.pop());
// console.log(numbersQ.pop());

// var namesQ = new Queue();
// namesQ.push("manish");
// namesQ.push("abhijeet");
// namesQ.push("ramakant");
// namesQ.push(10);

// console.log(namesQ.pop());
// console.log(namesQ.pop());
// console.log(namesQ.pop());
// console.log(namesQ.pop().toUpperCase());


// ---------------------------------------------- Generics
// class Queue<T> {
//     private _data: T[] = [];

//     push(d: T) {
//         this._data.push(d);
//     }

//     pop(): T | undefined {
//         return this._data.shift();
//     }
// }

// var numbersQ = new Queue<number>();
// numbersQ.push(10);
// numbersQ.push(20);
// numbersQ.push(30);

// console.log(numbersQ.pop());
// console.log(numbersQ.pop());
// console.log(numbersQ.pop());

// var namesQ = new Queue<string>();
// namesQ.push("manish");
// namesQ.push("abhijeet");
// namesQ.push("ramakant");
// // namesQ.push(10);

// console.log(namesQ.pop());
// console.log(namesQ.pop());
// console.log(namesQ.pop());
// console.log(namesQ.pop()?.toUpperCase());

// -------------------------------------------------------- Constraints

// function mergeObject<T1, T2>(arg1: T1, arg2: T2) {
//     return { ...arg1, ...arg2 };
// }

// function mergeObject<T1 extends object, T2 extends object>(arg1: T1, arg2: T2) {
//     return { ...arg1, ...arg2 };
// }

// let obj1 = { id: 1 };
// let obj2 = { name: "Manish" };

// let m1 = mergeObject<{ id: number }, { name: string }>(obj1, obj2);
// console.log(m1);

// // let m2 = mergeObject<{ id: number }, number>(obj1, 10);
// // console.log(m2);

// // let m3 = mergeObject<string, number>("Manish", 10);
// // console.log(m3);

// ---------------------------------------------
// interface IShape {
//     draw(): void;
// }

// class Circle implements IShape {
//     draw(): void {
//         console.log("Circle is Drawn")
//     }
// }

// class Square implements IShape {
//     draw(): void {
//         console.log("Square is Drawn")
//     }
// }

// function drawShapes<S extends IShape>(shapes: S[]): void {
//     for (const shape of shapes) {
//         shape.draw();
//     }
// }

// // drawShapes([{ id: 1 }]);
// drawShapes([new Circle(), new Square()]);

// -----------------------------------------------
// function getPropValue<T, K>(obj: T, key: K){
//     return obj[key];
// }

function getPropValue<T extends object, K extends keyof T>(obj: T, key: K) {
    return obj[key];
}

var person = { id: 1, name: "Manish", city: "Pune" };
let pname = getPropValue(person, "name");
console.log(pname);