// function* idGenerator() {
//     // console.log("Id Generator Called...");
//     var id = 0;
//     while (true) {
//         yield id++;
//     }
// }

// var seq = idGenerator();

// console.log(seq.next());
// console.log(seq.next());
// console.log(seq.next());
// console.log(seq.next());

// ----------------------------------------------------------------

// class GQueue<T> {
//     private _data: T[] = [];

//     push(d: T) {
//         this._data.push(d);
//     }

//     pop(): T | undefined {
//         return this._data.shift();
//     }

//     *[Symbol.iterator](): IterableIterator<T> {
//         for (let i = 0; i < this._data.length; i++) {
//             yield this._data[i];
//         }
//     }
// }

class GQueue<T> {
    private _data: T[] = [];

    push(d: T) {
        this._data.push(d);
    }

    pop(): T | undefined {
        return this._data.shift();
    }

    *[Symbol.iterator](): IterableIterator<T> {
        yield* this._data;
    }
}

var numsQ = new GQueue<number>();
numsQ.push(10);
numsQ.push(20);
numsQ.push(30);

for (const item of numsQ) {
    console.log(item);
}