// const area = function (rect: { h: number, w?: number }) {
//     rect.w = rect.w || rect.h;
//     return rect.h * rect.w;
// };

// let s1 = { h: 20, w: 30 };
// console.log(area(s1));

// let s2 = { h: 20, w: 30, d: 10 };
// console.log(area(s2));

// let s3 = { h: 20, d: 10 };
// console.log(area(s3));

// ------------------------------------------------------------------------
// interface IShape {
//     h: number;
//     w?: number;
// }

// const area = function (rect: IShape) {
//     rect.w = rect.w || rect.h;
//     return rect.h * rect.w;
// };

// let s1: IShape = { h: 20, w: 30 };
// console.log(area(s1));

// // let s2: IShape = { h: 20, w: 30, d: 10 };
// // console.log(area(s2));

// let s3: IShape = { h: 20 };
// console.log(area(s3));

// ------------------------------------------------------------------------
// interface IPerson {
//     name: string;
//     age: number;
//     greet(message: string) : string;
// }

// let p1: IPerson = {
//     name: "Abhijeet",
//     age: 39,
//     greet: function(m) {
//         return "Hello";
//     }
// };

// let p2: IPerson = {
//     name: "Ramakant",
//     age: 40,
//     greet: function(m) {
//         return "Hola";
//     }
// };

// console.log(p1.greet("Hi"));
// console.log(p2.greet("Hi"));

// ------------------------------------------------------------------- Interface Merging
// interface IShape {
//     height: number;
// }

// interface IShape {
//     height: number;
//     width: number;
// }

// let s1: IShape = {
//     height: 10,
//     width: 20
// };