import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lazy-two',
  template: `
    <h2 class="text-warning">Lazy Two Component from Lazy Module Loaded...</h2>
  `,
  styles: [
  ]
})
export class LazyTwoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
