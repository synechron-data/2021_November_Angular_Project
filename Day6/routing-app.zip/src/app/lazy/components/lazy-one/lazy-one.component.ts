import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lazy-one',
  template: `
    <h2 class="text-success">Lazy One Component from Lazy Module Loaded...</h2>
  `,
  styles: [
  ]
})
export class LazyOneComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
