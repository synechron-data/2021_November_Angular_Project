import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject, throwError } from 'rxjs';
import { catchError, map, retry } from 'rxjs/operators';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuthenticatorService {
  private url: string;
  private isLoggedIn: Subject<boolean>;

  get IsLoggedIn() { return this.isLoggedIn.asObservable(); }

  constructor(private httpClient: HttpClient) { 
    this.url = environment.accountUrl;
    this.isLoggedIn = new Subject<boolean>();
  }

  login(username: string, password: string) {
    return this.httpClient.post<any>(this.url, { username: username, password: password }).pipe(map(resObject => {
      if (resObject && resObject.token) {
        sessionStorage.setItem('tk', resObject.token);
        this.isLoggedIn.next(true);
      }
      return resObject;
    }),
      retry(3),
      catchError(this._handleError<any>('login', [])));
  }

  private _handleError<T>(operation = 'operation', result?: T) {
    return (err: HttpErrorResponse): Observable<T> => {
      console.log(`${operation} failed: ${err.message}`);
      console.log(err);
      return throwError(err.error.message);
    }
  }

  getToken() {
    return sessionStorage.getItem('tk');
  }

  logout() {
    sessionStorage.removeItem('tk');
    this.isLoggedIn.next(false);
  }
}
