import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { AuthenticatorService } from 'src/app/services/authenticator.service';

@Component({
  selector: 'bs-nav',
  templateUrl: './bs-nav.component.html',
  styleUrls: ['./bs-nav.component.css']
})
export class BsNavComponent implements OnInit, OnDestroy {
  private isLoggedIn: boolean;
  sub?: Subscription;

  constructor(private authenticatorService: AuthenticatorService) {
    this.isLoggedIn = false;
  }

  ngOnInit(): void {
    this.sub = this.authenticatorService.IsLoggedIn.subscribe((flag) => {
      this.isLoggedIn = flag;
    });
  }

  get IsLoggedIn() { return this.isLoggedIn; }

  ngOnDestroy(): void {
    this.sub?.unsubscribe();
  }
}
