export const environment = {
  production: true,
  usersUrl: 'http://www.synechron.com/api/users',
  accountUrl: 'http://www.synechron.com/account/getToken',
  productsUrl: 'http://www.synechron.com/api/products'
};
