// Variables created are optionally typesafe
// Untyped Variable - Not TypeSafe, Will Not get Intellisence (any)
// var data;
// data = 10;
// data = "ABC";

// Implictly Typed
// var data = 10;
// data = "ABC";               // Compile Time Error: Type 'string' is not assignable to type 'number'.

// var data = "Manish";
// data = 10;                  // Compile Time Error: Type 'number' is not assignable to type 'string'

// Explictly Typed
var age: number;
age = 10;
// age = "abc";                // Compile Time Error: Type 'string' is not assignable to type 'number'.

var city: string;
city = "Pune";

// Function to Add 2 numbers
// function add(x, y) {
//     return x + y;
// }

// function add(x: any, y: any) {
//     return x + y;
// }

function add(x: number, y: number) {
    return x + y;
}

console.log(add(2, 3));
console.log(add(2.5, 3.5));
console.log(add(0b1001, 0b1011));
console.log(add(0o1001, 0o1011));
console.log(add(0x1001, 0x1011));

// console.log(add(2, "abc"));
// console.log(add("abc", "xyz"));

// number / string / boolean / undefined / Array / object / Date / RegExp / function / void
// All the new Types which are supported by JavaScript
// Lefthand Side of assignment operator, all JavaScript Types

// var a: Array<number>;
// var s: symbol;
// var p: Promise<void>;

// Righthand Side of assignment Operator, API's will come
// You can only use them with proper configuration
// Based on target and lib section configured in your tsconfig.json

// a = new Array<number>();
// s = Symbol("Hello");
// p = new Promise((resolve, reject) => { });

// Browser API (lib => DOM)
// console
// document
// navigator
// screen

// ECMASCRIPT (lib => ES2015)

// TypeScript Types
// class / interface / enums / tuple / any / never / unknown