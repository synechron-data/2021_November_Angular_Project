var tg_Array: (string | number)[];
tg_Array = ["Manish", 1];
tg_Array = ["Manish", "Pune"];
tg_Array = [10, 20, 30];
tg_Array = [1, "Manish"];
tg_Array = [1, "Manish", "Pune", 411021];

// Tuple - Stores a fixed collection of values of same or varied types, maintaining the sequence
let dataRow: [number, string];
dataRow = [1, "Manish"];
// dataRow = ["Manish", 1];
// dataRow = ["Manish", "Pune"];
// dataRow = [10, 20, 30];
// dataRow = [1, "Manish", "Pune", 411021];