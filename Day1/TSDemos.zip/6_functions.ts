// // Function Declaration Syntax

// function hello1() {
//     console.log("Hello One World!");
// }

// hello1();

// // Function Expression Syntax

// const hello2 = function () {
//     console.log("Hello Two World!");
// }

// hello2();

// // Lambda Syntax

// const hello3 = () => {
//     console.log("Hello Three World!");
// }

// hello3();

// ------------------------------------------

// function hello1(): void {
//     console.log("Hello World");
// }

// function hello2(): undefined {
//     console.log("Hello World");
//     return undefined;
// }

// function hello3(): unknown {
//     console.log("Hello World");
//     return 10;
// }

// function iterate(): never {
//     let i = 0;
//     while (true) {
//         console.log(i++);
//     }
// }

// iterate();
// console.log("Waiting.....");

// ------------------------------------------

// int add1(int x, int y) {
//     return x + y;
// }

function add1(x: number, y: number): number {
    return x + y;
}

const add2 = function (x: number, y: number): number {
    return x + y;
}

let add3: (a: number, b: number) => number
add3 = function (x: number, y: number): number {
    return x + y;
};

let num: number;
num = 10;

let add4: (a: number, b: number) => number
add4 = function (x, y) {
    return x + y;
};

// Multiline Lambda
let add5: (a: number, b: number) => number
add5 = (x, y) => {
    return x + y;
};

// Singleline Lambda
let add6: (a: number, b: number) => number
add6 = (x, y) => x + y;

console.log(add1(2, 3));
console.log(add2(2, 3));
console.log(add3(2, 3));
console.log(add4(2, 3));
console.log(add5(2, 3));
console.log(add6(2, 3));
