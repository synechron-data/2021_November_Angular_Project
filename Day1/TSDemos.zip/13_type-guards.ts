var ndata: number = 10;
var sdata: string = "Manish";

// Type Guard
// Type Guards allow you to narrow down the type of a variable within a conditional block.

var sndata: string | number;
sndata = "Manish";
sndata = 10;

var snArr: (string | number)[];
snArr = [1, 2, 3, "Manish"];