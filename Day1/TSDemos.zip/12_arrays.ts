// var arr1 = [10, 20, 30];
// var arr2 = ["Manish", "Abhijeet", "Ramakant"];

// var arr3: number[];
// arr3 = [10, 20, 30, 40, 50];

// var arr4: Array<number>;
// arr4 = [10, 20, 30, 40, 50];

// var arr5: Array<number> = [10, 20, 30, 40, 50];

// var arr6 = new Array(10);       // Size
// console.log(arr6);
// console.log(arr6.length);

// var arr6 = new Array(1);
// arr6[0] = 10;
// arr6[1] = 20;
// arr6[2] = 30;
// console.log(arr6.length);

// var arr7 = new Array("Manish");
// console.log(arr7);
// console.log(arr7.length);

// var arr8 = Array.of(10);
// console.log(arr8);
// console.log(arr8.length);

// var arr = [10, 20, 30];

// var arr9 = new Array(arr);
// console.log(arr9);

// var arr10 = Array.from(arr);
// console.log(arr10);

// var arr11 = [...arr];
// console.log(arr11);

// var arr = new Array<number>(2);

// arr.push(10);
// arr.push(20);
// arr.push(30);

// console.log(arr);

// arr.unshift(2);
// arr.unshift(1);

// console.log(arr);

// arr.splice(2, 1, 3);
// console.log(arr);

// Array of objects, each object should have id, name and city
var empList: Array<{ id: number, name: string, city: string }>;

empList = [
    { id: 1, name: "Manish", city: "Pune" },
    { id: 2, name: "Ramakant", city: "Delhi" },
    { id: 3, name: "Abhijeet", city: "Pune" },
    { id: 4, name: "Subodh", city: "Mumbai" },
    { id: 5, name: "Abhishek", city: "Mathura" }
];

// for (let i = 0; i < empList.length; i++) {
//     console.log(`${i}       ${JSON.stringify(empList[i])}`);
// }

// for (const item of empList) {
//     console.log(`${JSON.stringify(item)}`);
// }

// for (const item of empList.entries()) {
//     console.log(`${JSON.stringify(item)}`);
// }

// for (const [index, item] of empList.entries()) {
//     console.log(`${index}       ${JSON.stringify(item)}`);
// }

// ------------------------------------------------------

// var pune_emps = empList.filter(e => e.city === "Pune");
// console.log(pune_emps);

var r1 = empList.find(e => e.id === 4);
console.log(r1);

var r2 = empList.findIndex(e => e.id === 4);
console.log(r2);

var r3 = empList.map(e => e.name.toUpperCase());
console.log(r3);