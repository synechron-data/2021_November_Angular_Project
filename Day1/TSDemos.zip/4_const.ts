// let j: number;
// j = 20;
// j = 30;

// // const env: string;          // Compile Time Error: 'const' declarations must be initialized.

// const env = "development";
// console.log(env);

// // env = "production";         // Compile Time Error: Cannot assign to 'env' because it is a constant.
// // const env = "production";   // Compile Time Error: Cannot redeclare block-scoped variable 'env'

// if (true) {
//     const env = "production";
//     console.log("Block: ", env);
// }

const obj = { id: 1 };
console.log(obj);

// obj = { name: "Manish" };           // Compile Time Error: Cannot assign to 'obj' because it is a constant.

obj.id = 1000;
console.log(obj);

// const keyword supports block scoping
// const must be initialized at the time of declaration
// const cannot be re-initialized
// const will not support hoisting
// Using const, we cannot create variables with name in the same scope

// let keyword supports block scoping
// let may or may not be initialized at the time of declaration
// let can be re-initialized
// let will not support hoisting
// Using let, we cannot create variables with name in the same scope

// var keyword does not supports block scoping
// var may or may not be initialized at the time of declaration
// var can be re-initialized
// var supports hoisting
// Using var, we can create variables with name in the same scope