function hello_js(name) {
    console.log("Hello, ",name);
}

hello_js("Manish");
hello_js();
hello_js("Abhijeet", "Pune");