import { Component } from '@angular/core';

@Component({
  selector: 'template-driven-form',
  templateUrl: './template-driven-form.component.html'
})
export class TemplateDrivenFormComponent {
  logForm(frm: any) {
    if (frm.invalid)
      console.error("Invalid Input...");
    else
      console.log(frm.value);
  }
}
