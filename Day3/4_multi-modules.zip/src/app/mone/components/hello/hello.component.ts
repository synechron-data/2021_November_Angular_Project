import { Component } from '@angular/core';

@Component({
  selector: 'hello',
  template: `
    <h2 class="text-primary">Local Hello Component - Module One</h2>
  `
})
export class HelloComponent { }