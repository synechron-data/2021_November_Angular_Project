import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'comp-two',
  template: `
    <div class="row">
      <h1 class="text-success">Hello from Component Two - Module Two</h1>
      <hello></hello>
      <scomp></scomp>
    </div>
  `,
  styles: [
  ]
})
export class CompTwoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
