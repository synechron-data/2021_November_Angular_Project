import { Component } from '@angular/core';

@Component({
  selector: 'hello',
  template: `
    <h2 class="text-success">Local Hello Component - Module Two</h2>
  `
})
export class HelloComponent { }