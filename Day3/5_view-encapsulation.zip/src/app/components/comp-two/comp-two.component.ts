// 1. Element inline Style
// import { Component } from '@angular/core';

// @Component({
//   selector: 'comp-two',
//   template: `
//     <h1 class="text-success">Hello from Component Two</h1>
//     <h2 style="border-style: dashed; border-width: 2px; border-color: green;">From Component Two</h2>
//   `
// })
// export class CompTwoComponent {}

// 2. Template Style
// import { Component, ViewEncapsulation } from '@angular/core';

// @Component({
//   selector: 'comp-two',
//   template: `
//     <style>
//       .card {
//         border-style: dashed; 
//         border-width: 2px; 
//         border-color: green;
//       }
//     </style>
//     <h1 class="text-success">Hello from Component Two</h1>
//     <h2 class="card">From Component Two</h2>
//   `,
//   encapsulation: ViewEncapsulation.ShadowDom
// })
// export class CompTwoComponent { }

// 3. Component Style
// import { Component } from '@angular/core';

// @Component({
//   selector: 'comp-two',
//   template: `
//     <h1 class="text-success">Hello from Component Two</h1>
//     <h2 class="card">From Component Two</h2>
//   `,
//   styles: [`
//     .card {
//       border-style: dashed; 
//       border-width: 2px; 
//       border-color: green;
//     }
//   `]
// })
// export class CompTwoComponent { }

// 4. External CSS
import { Component } from '@angular/core';

@Component({
  selector: 'comp-two',
  template: `
    <h1 class="text-success">Hello from Component Two</h1>
    <h2 class="card">From Component Two</h2>
  `,
  styleUrls: ['./comp-two.component.css']
})
export class CompTwoComponent { }