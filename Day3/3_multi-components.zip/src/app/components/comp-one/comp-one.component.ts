import { Component } from '@angular/core';

@Component({
  selector: 'comp-one',
  template: `
    <div class="row">
      <h1 class="text-primary">Hello from Component One</h1>
    </div>
  `
})
export class CompOneComponent { }
