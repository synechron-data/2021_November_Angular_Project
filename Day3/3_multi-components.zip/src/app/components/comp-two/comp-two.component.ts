import { Component } from '@angular/core';

@Component({
  selector: 'comp-two',
  template: `
    <div class="row">
      <h1 class="text-success">Hello from Component Two</h1>
    </div>
  `
})
export class CompTwoComponent { }
