import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Post } from "../models/post.model";
import { catchError, delay, retry } from "rxjs/operators";
import { Observable, throwError } from "rxjs";

@Injectable()
export class PostsService {
    private url: string;

    constructor(private httpClient: HttpClient) {
        this.url = "https://jsonplaceholder.typicode.com/posts";
    }

    // getAllPosts() {
    //     return this.httpClient.get<Array<Post>>(this.url);
    // }

    getAllPosts() {
        return this.httpClient.get<Array<Post>>(this.url).pipe(
            delay(3000),
            retry(3),
            catchError(this._handleError('getAllPosts', []))
        );
    }

    insertPost(postToInsert: Post) {
        return this.httpClient.post<Post>(this.url, postToInsert).pipe(
            delay(3000),
            retry(3),
            catchError(this._handleError('insertPost', postToInsert))
        );
    }

    editPost(postId: number, postToUpdate: Post) {
        var editUrl = `${this.url}/${postId}`;
        return this.httpClient.put<Post>(editUrl, postToUpdate).pipe(
            delay(3000),
            retry(3),
            catchError(this._handleError('editPost', postToUpdate))
        );
    }

    deletePost(postId: number) {
        var deleteUrl = `${this.url}/${postId}`;
        return this.httpClient.delete(deleteUrl).pipe(
            delay(3000),
            retry(3),
            catchError(this._handleError('deletePost'))
        );
    }

    private _handleError<T>(operation = 'operation', result?: T) {
        return (err: HttpErrorResponse): Observable<T> => {
            // Error Logging
            console.log(`${operation} failed: ${err.message}`);
            return throwError('Connection Error, please try again later...');
        }
    }
}