import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { User } from 'src/app/models/user.model';
import { UsersService } from 'src/app/services/users.service';

@Component({
  selector: 'assign',
  templateUrl: './assign.component.html'
})
export class AssignComponent implements OnInit, OnDestroy {
  users?: Array<User>;
  message: string;
  get_sub?: Subscription;

  constructor(private usersService: UsersService) {
    this.message = "Loading Data, please wait...";
  }

  ngOnInit(): void {
    this.get_sub = this.usersService.getAllUsers().subscribe(resData => {
      this.users = [...resData];
      this.message = "";
    }, (err: string) => {
      this.message = err;
    });
  }

  ngOnDestroy(): void {
    this.get_sub?.unsubscribe();
  }
}
