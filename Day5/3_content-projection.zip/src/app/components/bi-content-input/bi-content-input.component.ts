import { Component, ContentChild, HostBinding, Input, OnInit } from '@angular/core';
import { InputRefDirective } from 'src/app/directives/input-ref.directive';

@Component({
  selector: 'bi-content-input',
  templateUrl: './bi-content-input.component.html',
  styleUrls: ['./bi-content-input.component.css']
})
export class BiContentInputComponent implements OnInit {
  @Input() icon?: string;

  @ContentChild(InputRefDirective)
  input?: InputRefDirective;

  constructor() { }

  ngOnInit(): void {
  }

  get classes() {
    const cssClasses: any = {
      bi: true
    };

    cssClasses["bi-" + this.icon] = true;
    return cssClasses;
  }

  @HostBinding('class.focus')
  get focus() {
    return this.input ? this.input?.focus : false;
  }
}