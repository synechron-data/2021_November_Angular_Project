import { Component, EventEmitter, HostBinding, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'bi-input',
  templateUrl: './bi-input.component.html',
  styleUrls: ['./bi-input.component.css']
})
export class BiInputComponent implements OnInit {
  @Input() icon?: string;
  @Input() type: string;
  @Output() value: EventEmitter<string>;

  inputFocus: boolean;

  constructor() {
    this.type = "text";
    this.value = new EventEmitter<string>();
    this.inputFocus = false;
  }

  ngOnInit(): void {
  }

  get classes() {
    const cssClasses: any = {
      bi: true
    };

    cssClasses["bi-" + this.icon] = true;

    return cssClasses;
  }

  @HostBinding('class.focus')
  get focus() {
    return this.inputFocus;
  }
}
